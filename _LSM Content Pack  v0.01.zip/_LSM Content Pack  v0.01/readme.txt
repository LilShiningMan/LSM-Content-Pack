
LIL SHINING MAN'S CONTENT PACK v 0.01 (2020.08.03)

----------------------------------------------------
----------------------------------------------------

When adding this content to your game, you can either choose to add it every time you start a new world via enabling it at the World Mods menu OR you can follow the instructions below to add it permanently to your game and forget about enabling or disabling it.


* INSTALLING VIA MOD MENU ON A NEW GAME *


To install this content pack on world gen via the ingame mod menu, unzip to your Cata folder --  <game folder>\data\mods.

Create a new world and ensure the content pack is selected under World Mods/Buildings. 





* INSTALLING ON AN IN-PROGRESS GAME OR WITHOUT ENABLING VIA MOD OPTIONS *


If you wish to add this content to an in-progress game, or otherwise enable it permanently without selecting it via the mod list, simply delete the modinfo.json file from the unzipped folder, place remaining contents in  <game folder>\data\json\mapgen, and your current game should add this content when generating new map screens.


  
