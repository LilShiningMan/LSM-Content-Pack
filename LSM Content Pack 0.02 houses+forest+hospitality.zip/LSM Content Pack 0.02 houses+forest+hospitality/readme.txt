
LIL SHINING MAN'S CONTENT PACK v 0.02 (2021.07.11)
________________________________________________________________________________________________________________________________________________________________
________________________________________________________________________________________________________________________________________________________________


  1. INSTALLATION
  2. VERSION UPDATES
  




________________________________________________________________________________________________________________________________________________________________
                                                            1. INSTALLATION 
________________________________________________________________________________________________________________________________________________________________



There are two options when adding this content to your game: either add it manually via the mods menu at world gen *OR* add it to the game files so that it is integrated into the game by default.


                                             * INSTALLING VIA MOD MENU ON A NEW GAME *

To install this content pack on world gen via the ingame mod menu:

1. Unzip to your Cata folder --  <game folder>\data\mods.
2. Create a new world and ensure the content pack is selected under World Mods/Buildings. 




                                   * INSTALLING ON AN IN-PROGRESS GAME OR WITHOUT ENABLING VIA MOD OPTIONS *


If you wish to add this content to an in-progress game, or otherwise enable it permanently without selecting it via the mod list:

1. Delete the modinfo.json file from the unzipped folder
2. Place remaining contents in <game folder>\data\json\mapgen, and your current game should add this content when generating new overmap screens.


 

________________________________________________________________________________________________________________________________________________________________
                                                             2. VERSION UPDATES
________________________________________________________________________________________________________________________________________________________________



   v 0.02 (2021.07.30) houses+forest+hospitality+apartments
   _________________________________________________________

+ added a new house; 41 Total
+ added a new liquorstore with looted variant
+ added a new derelict cabin layout with a few variants for weirdness' sake
+ the forest is a little *weirder* now
+ new bar and restaurant palette; 1 new two-storey bar and grill layout
+ new restaurant and bar-centric items: new types of alcohol, big tubs of condiments, glassware, commercial laundry bag, as well as menus and receipts for, *ahem* flavor
+ added a new generic building palette to be used in conjunction with new apartment and commercial structures palettes. This is going to speed up adding new types of apartment buildings, stores and other commercial buildings a *lot*.
+ added rudimentary generic encounter system to add variety to various building layouts.
+ added some content-pack versions of items found in CDDA for use with BN, with the hope of integrating some of these items into BN permanently at a later date
+ new items like yoga mats and autographed photos for home display cases and for restaurants, complete with random written messages to spice things up



    v 0.01 (2020.08.03) houses+
    ____________________________

+ added 40 houses with variants

